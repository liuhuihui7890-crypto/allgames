from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from .models import Game, UserGameProgress, UserProfile
from .serializers import GameSerializer, ProgressSerializer

class GameViewSet(viewsets.ModelViewSet):
    queryset = Game.objects.filter(is_public=True)
    serializer_class = GameSerializer
    permission_classes = [permissions.AllowAny]

class ProgressViewSet(viewsets.GenericViewSet):
    serializer_class = ProgressSerializer
    permission_classes = [permissions.IsAuthenticated]

    @action(detail=False, methods=['post'])
    def save(self, request):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        game = serializer.validated_data['game']
        progress = serializer.validated_data['progress']
        obj, created = UserGameProgress.objects.update_or_create(
            user=request.user, game=game, defaults={'progress': progress}
        )
        return Response({'status': 'ok'}, status=status.HTTP_200_OK)