from django.db import models
from django.contrib.auth import get_user_model
from django.utils.text import slugify

User = get_user_model()

class Game(models.Model):
    PLATFORM_WEB = "web"
    PLATFORM_MOBILE = "mobile"
    PLATFORM_CHOICES = [
        (PLATFORM_WEB, "Web"),
        (PLATFORM_MOBILE, "Mobile"),
    ]

    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=200, unique=True, blank=True)
    url = models.URLField(help_text="游戏外链或内部托管地址")
    thumbnail = models.URLField(blank=True, null=True)
    description = models.TextField(blank=True)
    platform = models.CharField(max_length=10, choices=PLATFORM_CHOICES, default=PLATFORM_WEB)
    is_public = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)[:200]
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    coins = models.PositiveIntegerField(default=0)

class UserGameProgress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="game_progress")
    game = models.ForeignKey(Game, on_delete=models.CASCADE)
    progress = models.JSONField(default=dict)  # 存储关卡、分数、时间点等
    last_played = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ("user", "game")