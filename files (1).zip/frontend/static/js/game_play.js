(function(){
  const key = 'progress_' + window.GAME.slug;

  function saveLocal(progress) {
    localStorage.setItem(key, JSON.stringify({progress, ts: Date.now()}));
  }

  function loadLocal() {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : null;
  }

  async function saveServer(progress) {
    try {
      await fetch('/api/progress/save/', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({game: window.GAME.id, progress})
      });
    } catch (e) { console.error(e); }
  }

  // 示例：从 iframe 收到进度消息（由游戏调用 postMessage）
  window.addEventListener('message', (ev) => {
    if (!ev.data || ev.data.type !== 'game_progress') return;
    const progress = ev.data.payload;
    if (window.GAME.loggedIn) {
      saveServer(progress);
    } else {
      saveLocal(progress);
    }
  });

  // 登录后合并本地进度到服务器
  if (window.GAME.loggedIn) {
    const local = loadLocal();
    if (local) {
      saveServer(local.progress).then(() => localStorage.removeItem(key));
    }
  }
})();