#!/usr/bin/env bash
# Fixed create_and_push script for Git Bash / WSL
# Usage:
#   1) In an existing repo root:
#        chmod +x create_and_push_fixed.sh
#        ./create_and_push_fixed.sh
#   2) To init a repo and push to remote directly:
#        REMOTE_URL=git@github.com:liuhuihui062-png/Mini-Game-Management-Platform.git ./create_and_push_fixed.sh

set -euo pipefail

BRANCH="fastapi-skeleton"
REMOTE_URL=${REMOTE_URL:-""}

echo "Running create_and_push_fixed.sh"
echo "Branch: ${BRANCH}"
if [ -n "${REMOTE_URL}" ]; then
  echo "REMOTE_URL provided: ${REMOTE_URL}"
fi

# Helper: write file with content (here-doc)
write() {
  local path="$1"
  shift
  mkdir -p "$(dirname "$path")"
  cat > "$path" <<'EOF'
'"$*"'
EOF
}

# We'll use simple cat <<'EOF' ... EOF blocks below to avoid quoting issues.

# README.md
cat > README.md <<'EOF'
# Mini-Game-Management-Platform (FastAPI 骨架)

快速启动的 FastAPI 小游戏平台骨架，包含：
- 用户注册 / 登录（JWT）
- 游戏商店（列出游戏）
- 嵌入式游戏播放页（iframe + 手机容器）
- 已登录用户的游戏进度保存（server-side）与金币发放（简单防重放）

快速开始（本地开发）：
1. 创建虚拟环境并安装依赖：