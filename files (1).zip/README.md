# Mini-Game-Management-Platform (FastAPI 骨架)

快速启动的 FastAPI 小游戏平台骨架，包含：
- 用户注册 / 登录（JWT）
- 游戏商店（列出游戏）
- 嵌入式游戏播放页（iframe + 手机容器）
- 已登录用户的游戏进度保存（server-side）与金币发放（简单防重放）

快速开始（本地开发）：
1. 创建虚拟环境并安装依赖：
   ```
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
2. 启动（开发）：
   ```
   export DATABASE_URL="sqlite:///./dev.db"
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```
3. 打开浏览器访问 `http://127.0.0.1:8000/games`

使用 Docker（包含 Postgres）：
```
docker-compose up --build
# 访问 http://localhost:8000/games
```

注意事项：
- 生产环境请使用 PostgreSQL、Redis（用于 rate-limiting / 去重）、HTTPS 与更严格的安全策略。
- 当前示例直接在应用启动时创建表；生产建议使用 Alembic 进行迁移。

后续我可以：
- 把项目推送到你的 GitHub 仓库并创建 issue 列表
- 添加单元测试、CI 配置与部署脚本