#!/usr/bin/env bash
# Create project files for the FastAPI mini-game skeleton and push to remote branch `fastapi-skeleton`.
# Usage:
#   1) If you already cloned your (empty) repo, cd into repo root and run:
#        chmod +x create_and_push.sh
#        ./create_and_push.sh
#
#   2) If you did NOT clone and want the script to init a git repo and push to a remote,
#      provide REMOTE_URL environment variable (e.g. git@github.com:liuhuihui062-png/Mini-Game-Management-Platform.git):
#        REMOTE_URL=git@github.com:liuhuihui062-png/Mini-Game-Management-Platform.git ./create_and_push.sh
#
# The script will:
# - create files and directories for the FastAPI skeleton (app/, frontend/, Dockerfile, etc.)
# - init git if needed
# - create branch fastapi-skeleton
# - commit and push to origin (or REMOTE_URL if provided)
#
# NOTE:
# - Ensure you have push access to the remote.
# - If your git user.name / user.email are not set, the script will set local repo defaults.

set -euo pipefail

BRANCH="fastapi-skeleton"
REMOTE_URL=${REMOTE_URL:-""}

# helper to write files with proper permissions
write_file() {
  local path="$1"
  local content="$2"
  mkdir -p "$(dirname "$path")"
  cat > "$path" <<'EOF'
'"$content"'
EOF
}

echo "Creating project structure..."

# README.md
cat > README.md <<'EOF'
# Mini-Game-Management-Platform (FastAPI 骨架)

快速启动的 FastAPI 小游戏平台骨架，包含：
- 用户注册 / 登录（JWT）
- 游戏商店（列出游戏）
- 嵌入式游戏播放页（iframe + 手机容器）
- 已登录用户的游戏进度保存（server-side）与金币发放（简单防重放）

快速开始（本地开发）：
1. 创建虚拟环境并安装依赖：